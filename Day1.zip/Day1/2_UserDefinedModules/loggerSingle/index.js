const Logger = require('./Logger');

var instance = null;

function getInstance() {
    instance = new Logger();
    return instance;
}

module.exports.Logger = getInstance();
// module.exports.Logger = getInstance;
