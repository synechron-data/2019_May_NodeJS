class Logger {
    log(m){
        console.log(m + ", logged using Logger Class method.");
    }
}

module.exports = Logger;