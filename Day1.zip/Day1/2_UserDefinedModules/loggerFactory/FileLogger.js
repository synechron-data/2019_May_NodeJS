class FileLogger {
    log(m){
        console.log(m + ", logged in File.");
    }
}

module.exports = FileLogger;