class DBLogger {
    log(m){
        console.log(m + ", logged in Database.");
    }
}

module.exports = DBLogger;