module.exports = "From logger1/index.js File";

console.log(process.cwd());
console.log(__dirname);