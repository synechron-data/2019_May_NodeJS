// const message = require('./message.js');
// console.log(message);
// message.log("Synechron");

// const message = require('./message');
// var e1 = new message.Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// const logger = require('./logger');
// console.log(logger);

// const logger1 = require('./logger1');
// console.log(logger1);

// const loggerService = require('./loggerService');
// loggerService.log("From App.js");

// const loggerFactory = require('./loggerFactory');
// // console.log(loggerFactory);

// var dbLogger = loggerFactory.DBLFactory.getLogger();
// dbLogger.log("Hi");

// var fLogger = loggerFactory.FLFactory.getLogger();
// fLogger.log("Hi");

const loggerSingle = require('./loggerSingle');
// console.log(loggerSingle);

let logger1 = loggerSingle.Logger;
let logger2 = loggerSingle.Logger;

// let logger1 = loggerSingle.Logger();
// let logger2 = loggerSingle.Logger();

console.log(logger1 === logger2);