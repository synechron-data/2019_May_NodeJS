module.exports.log = function (m) {
    const Logger = require('./Logger');
    Logger.log(m);
}