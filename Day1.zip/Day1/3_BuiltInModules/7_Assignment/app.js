const fs = require('fs');

module.exports.PDFHandler = function (req, res) {
    if (req.url != "/favicon.ico") {
        var filepath = `${process.cwd()}${req.url}.pdf`;
        var readStream = fs.createReadStream(filepath);
        res.setHeader("content-type", "application/pdf");

        // readStream.on('data', function (chunk) {
        //     res.write(chunk);
        // })

        // readStream.on('end', function (chunk) {
        //     res.end();
        // })

        readStream.pipe(res);

        readStream.on('error', function (err) {
            res.setHeader("content-type", "text");
            res.end("Error Reading File..");
        })
    }
}