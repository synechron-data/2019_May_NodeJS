// const repl = require('repl');
// let modules = repl._builtinLibs;
// console.log(modules);

const readline = require('readline');
// console.log(readline);

var rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// console.log(rl);
// rl.question("Enter a number: ", function (n1) {
//     console.log("You entered %s", n1);
//     rl.close();
// });

rl.question("Enter a number: ", function (n1) {
    var x = parseInt(n1);
    rl.question("Enter a number: ", function (n2) {
        var y = parseInt(n2);
        var sum = x + y;
        console.log("Result is %s", sum);
        rl.close();
    });
});

// console.log("Last Line................");
