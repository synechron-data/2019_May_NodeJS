// const http = require('http');

// var server = http.createServer((req, res) => {
//     console.log(req.headers);
//     res.setHeader("content-type", "text/html");
//     res.write("<h1>Response from Node Http Server</h1>");
//     res.end();
// });

// server.listen(3000, () => {
//     console.log("Server Started...");
// });

const http = require('http');
const fs = require('fs');

var server = http.createServer((req, res) => {
    fs.readFile('./index.html', (err, html) => {
        if (err) throw err;

        res.setHeader("content-type", "text/html");
        res.write(html);
        res.end();
    })
});

server.listen(3000, () => {
    console.log("Server Started...");
});