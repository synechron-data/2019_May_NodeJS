const StringEmitter = require('./StringEmitter');

let sEmitter = new StringEmitter();

sEmitter.on('data', function (s) {
    console.log("S1 - ", s);
})

var count = 0;
function S2(s) {
    ++count;
    console.log("S2 - ", s.toUpperCase());
    if (count > 2) {
        sEmitter.removeListener('data', S2);
    }
}

sEmitter.on('data', S2)

// sEmitter.getStringCB(function (s) {
//     console.log(s);
// });

// setInterval(function () {
//     var s = sEmitter.getString();
//     console.log(s);
// }, 2000);