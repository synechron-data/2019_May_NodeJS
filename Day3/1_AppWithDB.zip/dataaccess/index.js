const monk = require('monk');
const db = monk('localhost/appdb');
const collection = db.get('usercollection');

module.exports.getAllUsers = function () {
    return new Promise((resolve, reject) => {
        collection.find({}).then((data) => {
            resolve(data);
        }, (err) => {
            // Log the Actual Error 
            reject("Some Error, Contact DAL Developer");
        });
    });
}

module.exports.getUserById = function (id) {
    return new Promise((resolve, reject) => {
        collection.findOne({ _id: monk.id(id) }).then((data) => {
            resolve(data);
        }, (err) => {
            // Log the Actual Error 
            reject("Some Error, Contact DAL Developer");
        });
    });
}

module.exports.insertUser = function (user) {
    return new Promise((resolve, reject) => {
        collection.insert(user).then((data) => {
            resolve(data);
        }, (err) => {
            // Log the Actual Error 
            reject("Some Error, Contact DAL Developer");
        });
    });
}

module.exports.updateUser = function (id, user) {
    return new Promise((resolve, reject) => {
        collection.findOneAndUpdate({ _id: monk.id(id) }, { $set: user }).then(function (data) {
            resolve(data);
        }, function (err) {
            console.log(err);
            reject("Some Error, Contact DAL Developer.");
        })
    });
}

module.exports.deleteUser = function (id) {
    return new Promise((resolve, reject) => {
        collection.findOneAndDelete({ _id: monk.id(id) }).then(function (data) {
            resolve();
        }, function (err) {
            console.log(err);
            reject("Some Error, Contact DAL Developer.");
        })
    });
}