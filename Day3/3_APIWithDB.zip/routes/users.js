var express = require('express');
var router = express.Router();

const userApiCtrl = require('../controllers/userApiController');
const accCtrl = require('../controllers/accountController');

router.post('/authenticate', accCtrl.authenticate);

router.use(accCtrl.checkToken);

router.get('/', userApiCtrl.index);

router.get('/:id', userApiCtrl.details);

router.post('/', userApiCtrl.create_user);

router.put('/:id', userApiCtrl.edit_user);

router.delete('/:id', userApiCtrl.delete_user);

module.exports = router;
