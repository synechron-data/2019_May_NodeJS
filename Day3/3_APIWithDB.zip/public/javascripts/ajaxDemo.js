$(document).ready(function () {
    window.sessionStorage.clear();

    $.post('/users/authenticate', { username: 'manish', password: 'manish' },
        function (data, status) {
            // console.log(data);
            window.sessionStorage.setItem('tk', data.token);
        });


    $("#a1").click(function (e) {
        $("#ut_body").empty();

        e.preventDefault();
        var tk = window.sessionStorage.getItem('tk');

        $.ajax({
            url: '/users',
            type: 'GET',
            dataType: 'json',
            success: function (data) {
                var tmpl = $.templates("#userTemplate");
                var html = tmpl.render(data);
                $("#ut_body").append(html);
            },
            error: function (err) {
                console.log(err);
            },
            beforeSend: function (xhr) {
                xhr.setRequestHeader('x-access-token', tk);
            }
        });
    })

    // $.getJSON('/users', function(data){
    //     var tmpl = $.templates("#userTemplate");
    //     var html = tmpl.render(data);
    //     $("#ut_body").append(html);
    // });
})