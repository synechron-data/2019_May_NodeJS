const da = require('../dataaccess');

module.exports.index = function (req, res, next) {
    da.getAllUsers().then((data) => {
        res.json(data);
    }, (eMsg) => {
        console.log(eMsg);
    })
}

module.exports.details = function (req, res, next) {
    da.getUserById(req.params.id).then((data) => {
        res.json(data);
    }, (eMsg) => {
        console.log(eMsg);
    })
}

module.exports.edit_user = function (req, res, next) {
    da.updateUser(req.params.id, user).then((data) => {

    }, (eMsg) => {

    })
}

module.exports.delete_user = function (req, res, next) {
    da.deleteUser(req.params.id).then(() => {

    }, (eMsg) => {

    })
}

module.exports.create_user = function (req, res, next) {
    da.insertUser(user).then((data) => {

    }, (eMsg) => {

    })
}